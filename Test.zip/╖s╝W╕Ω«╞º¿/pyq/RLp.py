import gym

env = gym.make("MountainCar-v0")
env.reset()
env.render()